#!/usr/bin/env python3
"""Generate the browsable phrase-bank page from a skill pack's phrase-bank.md.

    python3 build_phrasebank_html.py                       # default skill
    python3 build_phrasebank_html.py --skill <name>
    python3 build_phrasebank_html.py --out /tmp/preview.html

Writes `<skill>/phrase-bank.html`, which LabUI serves at
`/api/rag/skills/<skill>/phrasebank.html` and embeds in the Phrase Bank tab.

The page is a self-contained artifact: open it directly in a browser and it
works. Inside LabUI it sits in an iframe and follows the app's theme toggle via
a postMessage bridge (`{type: 'labui-theme', theme: 'dark'|'light'}`), falling
back to `prefers-color-scheme` when opened standalone.

**Re-run this after editing phrase-bank.md** — the page is a build artifact, not
a live view. Everything else in the skill is read at request time; this is the
one thing that goes stale.

Stdlib only.
"""
from __future__ import annotations

import argparse
import html
import re
import sys
from pathlib import Path

SKILLS_DIR = Path(__file__).parent.resolve()
DEFAULT_SKILL = "nanobubble-paper-writer"

# Source keys → a human label for the filter chips' tooltips. Unknown keys still
# work; they just show the bare key.
SOURCE_META = {
    "Attard-2003":     "Attard, Adv. Colloid Interface Sci. 104 (2003)",
    "Yoon-2000":       "Yoon, Int. J. Miner. Process. 58 (2000)",
    "Jungwirth-2006":  "Jungwirth & Tobias, Chem. Rev. 106 (2006)",
    "JCIS-2015":       "Bubble–particle interactions, JCIS 449 (2015)",
    "Zhang-2016":      "Zhang & Seddon, Langmuir (2016)",
    "Meegoda-2019":    "Meegoda et al., Langmuir 35 (2019)",
    "Yasui-2019":      "Yasui et al., Langmuir",
    "Hewage-2021":     "Aluthgun Hewage et al., Colloids Surf. A 609 (2021)",
    "Alheshibri-2021": "Alheshibri et al., Curr. Opin. Colloid Interface Sci.",
    "Ma-2022":         "Ma, Li, Ohl et al., JCIS 606 (2022)",
    "Sullivan-2023":   "Sullivan et al., Int. J. Heat Mass Transf. 217 (2023)",
    "LB-2024":         "Nanobubbles on Langmuir–Blodgett films, JCIS 669 (2024)",
    "Abolfath-2024":   "Abolfath et al., arXiv:2403.05880",
    "Kubelka-JCIS":    "Kubelka, Taman & Piri, JCIS (R3) — house paper",
    "Khairy-2025":     "Khairy, Kubelka & Piri, Langmuir (2025) — your paper",
    "Box-1976":        "Box, J. Am. Stat. Assoc. 71 (1976)",
    "Cuntz-2010":      "Cuntz et al., PLoS Comput. Biol. 6 (2010)",
}
HOUSE_SOURCES = {"Kubelka-JCIS", "Khairy-2025"}

QUOTE_RE = re.compile(r'^>\s*"(.+?)"\s*—\s*([A-Za-z0-9\-]+)(?:,\s*(.+))?$')


def is_pattern_line(line: str) -> bool:
    """True when a line is (nearly) all backticked frames joined by ' / '.

    A prose line that merely opens with a backticked term is not a pattern line —
    that distinction keeps notes like "`respectively` is the corpus's standard
    device…" out of the pattern chips.
    """
    inside = sum(len(x) for x in re.findall(r"`([^`]+)`", line))
    outside = re.sub(r"`[^`]+`", "", line).strip()
    if not inside:
        return False
    if re.fullmatch(r"[/\s,.;()…]*", outside):
        return True
    return inside / max(len(line), 1) > 0.75


def parse(md: str) -> tuple[list[dict], list[tuple[str, str, str]]]:
    """→ (cards, budget_rows). One card per rhetorical move."""
    sections: list[dict] = []
    cur_sec = cur_move = None
    for line in md.split("\n"):
        if line.startswith("## "):
            cur_sec = {"title": line[3:].strip(), "moves": [], "notes": [], "ex": [], "bullets": []}
            sections.append(cur_sec)
            cur_move = None
        elif line.startswith("### ") and cur_sec:
            cur_move = {"title": line[4:].strip(), "patterns": [], "ex": [], "note": []}
            cur_sec["moves"].append(cur_move)
        elif line.startswith('> "'):
            m = QUOTE_RE.match(line)
            if m and cur_sec:
                e = {"q": m.group(1), "src": m.group(2), "sec": (m.group(3) or "").strip()}
                (cur_move["ex"] if cur_move else cur_sec["ex"]).append(e)
        elif line.startswith("`") and cur_move is not None and is_pattern_line(line):
            cur_move["patterns"] += [p for p in re.findall(r"`([^`]+)`", line) if len(p) > 3]
        elif line.startswith("- ") and cur_sec and not cur_move:
            cur_sec["bullets"].append(line[2:].strip())
        elif line.strip() and not line.startswith(("---", "|", "#")):
            (cur_move["note"] if cur_move else cur_sec["notes"] if cur_sec else []).append(line)

    cards: list[dict] = []
    for s in sections:
        title = s["title"]
        if title.startswith("0."):
            continue
        short = title.split(". ", 1)[-1]
        if s["ex"] or s["bullets"]:
            cards.append({
                "sec": title, "move": short, "ex": s["ex"], "bullets": s["bullets"],
                "patterns": [p for p in re.findall(r"`([^`]+)`", " ".join(s["notes"])) if len(p) > 3],
                "note": " ".join(s["notes"]),
            })
        for mv in s["moves"]:
            cards.append({"sec": title, "move": mv["title"], "patterns": mv["patterns"],
                          "ex": mv["ex"], "bullets": [], "note": " ".join(mv["note"])})

    budget = []
    for m in re.finditer(r"^\|\s*(.+?)\s*\|\s*\*{0,2}([\d.]+)\*{0,2}([^|]*)\|\s*(.+?)\s*\|$", md, re.M):
        label = re.sub(r"`", "", m.group(1)).strip()
        if label.lower().startswith(("marker", "property", "---")) or "|" in label:
            continue
        num = m.group(2) + (" " + m.group(3).strip() if m.group(3).strip() else "")
        budget.append((label, num, m.group(4).strip()))
    return cards, budget[:16]


def md_inline(text: str) -> str:
    t = html.escape(text)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*(.+?)\*", r"<em>\1</em>", t)
    return t


def card_html(c: dict) -> str:
    pats = "".join(f'<button class="pat" title="click to copy">{md_inline(p)}</button>'
                   for p in c["patterns"])
    exs = "".join(
        f'<blockquote class="{"house" if e["src"] in HOUSE_SOURCES else ""}">'
        f'<span class="q">{html.escape(e["q"])}</span>'
        f'<cite title="{html.escape(SOURCE_META.get(e["src"], e["src"]))}">{html.escape(e["src"])}'
        + (f' <span class="sec">· {html.escape(e["sec"])}</span>' if e["sec"] else "")
        + "</cite></blockquote>"
        for e in c["ex"])
    if c["bullets"]:
        exs += "<ul class='bl'>" + "".join(f"<li>{md_inline(b)}</li>" for b in c["bullets"]) + "</ul>"
    note = f'<p class="note">{md_inline(c["note"])}</p>' if c["note"] else ""
    haystack = " ".join([c["move"], *c["patterns"], *(e["q"] for e in c["ex"]),
                         *c["bullets"], c["note"]]).lower()
    return (f'<article class="card" data-sec="{html.escape(c["sec"])}" '
            f'data-text="{html.escape(haystack)}" '
            f'data-srcs="{html.escape(" ".join(e["src"] for e in c["ex"]))}">'
            f'<h3>{md_inline(c["move"])}<span class="tag">{html.escape(c["sec"])}</span></h3>'
            f'{"<div class=pats>" + pats + "</div>" if pats else ""}{exs}{note}</article>')


CSS = """
:root{--bg:#faf9f7;--card:#fff;--ink:#1c1b19;--mut:#6b6862;--line:#e6e3dd;--acc:#8a5a2b;--acc2:#f2ece3;--house:#b8842f}
@media(prefers-color-scheme:dark){html:not([data-theme="light"]){--bg:#16151a;--card:#1e1d23;--ink:#e9e7e2;--mut:#a09c94;--line:#2f2d35;--acc:#d9a163;--acc2:#2a2530;--house:#e0b464}}
html[data-theme="dark"]{--bg:#16151a;--card:#1e1d23;--ink:#e9e7e2;--mut:#a09c94;--line:#2f2d35;--acc:#d9a163;--acc2:#2a2530;--house:#e0b464}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.62 ui-serif,Georgia,'Iowan Old Style',serif}
header{position:sticky;top:0;z-index:20;background:var(--bg);border-bottom:1px solid var(--line);padding:14px 22px 10px}
h1{margin:0 0 2px;font-size:20px;letter-spacing:-.01em}
.sub{color:var(--mut);font-size:12.5px;font-family:ui-sans-serif,system-ui;margin-bottom:10px}
.controls{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
input[type=search]{flex:1 1 240px;min-width:200px;padding:8px 12px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--ink);font:14px ui-sans-serif,system-ui}
input[type=search]:focus{outline:2px solid var(--acc);outline-offset:-1px}
.chips{display:flex;gap:6px;flex-wrap:wrap;margin-top:9px}
.chip{border:1px solid var(--line);background:var(--card);color:var(--mut);border-radius:20px;padding:4px 11px;font:12px ui-sans-serif,system-ui;cursor:pointer}
.chip:hover{border-color:var(--acc);color:var(--ink)}
.chip.on{background:var(--acc);border-color:var(--acc);color:#fff}
.chip.src{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11px}
main{max-width:1180px;margin:0 auto;padding:20px 22px 80px;column-width:420px;column-gap:20px}
.card,.panel{break-inside:avoid;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:15px 17px;margin:0 0 18px;display:inline-block;width:100%}
.card[hidden],.panel[hidden],#empty[hidden]{display:none!important}
.card h3{margin:0 0 9px;font-size:15.5px;font-weight:600;display:flex;justify-content:space-between;align-items:baseline;gap:10px}
.tag{font:10.5px ui-sans-serif,system-ui;color:var(--mut);white-space:nowrap;letter-spacing:.02em;text-transform:uppercase;flex:0 0 auto}
.pats{margin:0 0 11px;display:flex;flex-wrap:wrap;gap:5px}
.pat{font:12.5px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;background:var(--acc2);color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:3px 8px;cursor:copy;text-align:left}
.pat:hover{border-color:var(--acc)}
.pat.copied{background:var(--acc);color:#fff}
blockquote{margin:0 0 9px;padding:8px 0 8px 12px;border-left:2.5px solid var(--line);font-size:14.5px}
blockquote.house{border-left-color:var(--house)}
.q{display:block}.q::before{content:'"'}.q::after{content:'"'}
cite{display:block;margin-top:4px;font:11px ui-sans-serif,system-ui;color:var(--mut);font-style:normal}
blockquote.house cite{color:var(--house);font-weight:600}
.sec{opacity:.75;font-weight:400}
.note{margin:9px 0 0;font-size:13.5px;color:var(--mut);line-height:1.55}
.bl{margin:0 0 4px;padding-left:18px;font-size:13.5px;line-height:1.55}
.bl li{margin-bottom:6px}
table{border-collapse:collapse;width:100%;font:12.5px ui-sans-serif,system-ui}
td,th{padding:4px 6px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
.num{text-align:right;font-family:ui-monospace,Menlo,monospace;white-space:nowrap}
code{font:12.5px ui-monospace,SFMono-Regular,Menlo,monospace;background:var(--acc2);padding:1px 4px;border-radius:4px}
.empty{color:var(--mut);font:14px ui-sans-serif,system-ui;padding:30px 0}
#count{font:12px ui-sans-serif,system-ui;color:var(--mut);margin-left:auto}
"""

JS = """
const q=document.getElementById('q'),cards=[...document.querySelectorAll('.card')],
 cnt=document.getElementById('count'),empty=document.getElementById('empty');
let fSec='*',fSrc='*';
function apply(){
 const t=q.value.trim().toLowerCase();let n=0;
 cards.forEach(c=>{
  const ok=(fSec==='*'||c.dataset.sec===fSec)&&(fSrc==='*'||c.dataset.srcs.includes(fSrc))
   &&(!t||c.dataset.text.includes(t));
  c.hidden=!ok;if(ok)n++;
 });
 cnt.textContent=n+' move'+(n===1?'':'s');empty.hidden=n>0;
}
q.addEventListener('input',apply);
document.getElementById('secs').addEventListener('click',e=>{
 if(!e.target.dataset.f)return;fSec=e.target.dataset.f;
 [...e.currentTarget.children].forEach(b=>b.classList.toggle('on',b===e.target));apply();});
document.getElementById('srcs').addEventListener('click',e=>{
 if(!e.target.dataset.s)return;fSrc=e.target.dataset.s==='*'?'*':e.target.dataset.s;
 [...e.currentTarget.children].forEach(b=>b.classList.toggle('on',b===e.target));apply();});
document.addEventListener('click',e=>{
 if(!e.target.classList.contains('pat'))return;
 const s=e.target.textContent;
 (navigator.clipboard?navigator.clipboard.writeText(s):Promise.reject()).then(()=>{
   e.target.classList.add('copied');setTimeout(()=>e.target.classList.remove('copied'),700);}).catch(()=>{});
});
document.addEventListener('keydown',e=>{if(e.key==='/'&&document.activeElement!==q){e.preventDefault();q.focus();}
 if(e.key==='Escape'){q.value='';apply();q.blur();}});
// Theme bridge: LabUI's shell posts its theme in; standalone falls back to the
// prefers-color-scheme media query in the stylesheet.
window.addEventListener('message',e=>{
 const d=e.data;
 if(d&&d.type==='labui-theme'&&(d.theme==='dark'||d.theme==='light'))
   document.documentElement.setAttribute('data-theme',d.theme);
});
if(window.parent!==window) window.parent.postMessage({type:'labui-phrasebank-ready'},'*');
apply();
"""


def build(skill: str = DEFAULT_SKILL, out: Path | None = None) -> Path:
    src = SKILLS_DIR / skill / "references" / "phrase-bank.md"
    if not src.is_file():
        raise SystemExit(f"no phrase-bank.md in skill '{skill}' ({src})")
    md = src.read_text(encoding="utf-8")
    cards, budget = parse(md)

    secnames: list[str] = []
    for c in cards:
        if c["sec"] not in secnames:
            secnames.append(c["sec"])

    chips = "".join(
        f'<button class="chip" data-f="{html.escape(s)}">{html.escape(s.split(". ", 1)[-1])}</button>'
        for s in secnames)
    used = {e["src"] for c in cards for e in c["ex"]}
    srcchips = "".join(
        f'<button class="chip src" data-s="{k}" title="{html.escape(SOURCE_META.get(k, k))}">{k}</button>'
        for k in SOURCE_META if k in used)
    budget_rows = "".join(
        f'<tr><td><code>{html.escape(a)}</code></td><td class="num">{html.escape(b)}</td>'
        f'<td>{md_inline(c)}</td></tr>' for a, b, c in budget)
    n_ex = sum(len(c["ex"]) for c in cards)

    page = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Phrase Bank — {html.escape(skill)}</title><style>{CSS}</style></head><body>
<header>
<h1>Phrase Bank</h1>
<div class="sub">{len(cards)} rhetorical moves &middot; {n_ex} attested exemplars, each verified verbatim
against ~76,000 words of published prose from 15 papers. Gold rule = house papers.
Click any pattern to copy. Press <kbd>/</kbd> to search.</div>
<div class="controls"><input type="search" id="q" placeholder="Search patterns, exemplars, notes… (e.g. 'gap', 'hedge', 'consistent with')" autocomplete="off"><span id="count"></span></div>
<div class="chips" id="secs"><button class="chip on" data-f="*">All sections</button>{chips}</div>
<div class="chips" id="srcs"><button class="chip src on" data-s="*">All sources</button>{srcchips}</div>
</header>
<main id="main">
<div class="panel"><h3 style="margin:0 0 8px;font-size:15px">The connective budget (measured)</h3>
<table><thead><tr><th>Marker</th><th class="num">per 1,000 w</th><th>Budget for a 6,000-word paper</th></tr></thead>
<tbody>{budget_rows}</tbody></table>
<p class="note"><strong>Zero occurrences</strong> in the whole corpus: <em>robust, delve, realm,
landscape, tapestry, testament, showcase, intricate, multifaceted, meticulous.</em> Any of them in a
draft is a defect.</p></div>
{"".join(card_html(c) for c in cards)}
<div class="empty" id="empty" hidden>No moves match that search.</div>
</main>
<script>{JS}</script></body></html>"""

    dest = out or (SKILLS_DIR / skill / "phrase-bank.html")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(page, encoding="utf-8")
    print(f"{dest}  —  {len(cards)} moves, {n_ex} exemplars, {len(budget)} budget rows, "
          f"{len(page):,} bytes")
    return dest


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--skill", default=DEFAULT_SKILL)
    ap.add_argument("--out", type=Path, default=None)
    a = ap.parse_args()
    sys.exit(0 if build(a.skill, a.out) else 1)
